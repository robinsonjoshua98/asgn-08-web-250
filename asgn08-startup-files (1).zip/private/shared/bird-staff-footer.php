<footer>
  &copy; <?php echo date('Y'); ?> WNC Birds
</footer>

</body>
</html>

<?php
 // db_disconnect($database);
?>
