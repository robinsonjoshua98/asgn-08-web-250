DROP USER 'web250user'@'localhost';
FLUSH PRIVILEGES;